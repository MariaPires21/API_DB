﻿using API_DB.Models.InputModels;
using API_DB.Models.ViewModels;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Data.SqlClient;

namespace API_DB.Models.Data
{
    public class MatriculaDB
    {
        private readonly IConexao _conexao;

        public MatriculaDB(IConexao conexao)
        {
            _conexao = conexao;
        }

        /* Implementar métodos para banco de dados */

        public async Task<List<MatriculaViewModel>> listar()
        {
            List<MatriculaViewModel> matriculas = new List<MatriculaViewModel>();

            using (SqlConnection conn = _conexao.getConexao())
            {
                string query = "select * from tbMatricula";
                SqlCommand command = new SqlCommand(query, conn);

                // Abrindo a conexão com o banco de dados
                conn.Open();

                // Usando um objeto DataReader para ler os dados do banco
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    // Enquanto conseguir ler algum dado do banco...
                    while (reader.Read())
                    {
                        // Obter os dados e criar um objeto Aluno
                        MatriculaViewModel matricula = new MatriculaViewModel();
                        matricula.IdCurso = Int32.Parse(reader["IdCurso"].ToString());
                        matricula.IdAluno = Int32.Parse(reader["IdAluno"].ToString());
                        matricula.DataMatricula = DateOnly.Parse(
                            reader["DataMatricula"].ToString().Substring(0, 10)
                        );

                        // Adicionando uma nova matrícula na lista
                        matriculas.Add(matricula);
                    }
                }

                // Fechando a conexão com o banco
                conn.Close();
            }

            return matriculas;
        }

        public async Task<MatriculaViewModel> obterPorId(int IdCurso, int IdAluno)
        {
            MatriculaViewModel matricula = null;

            using (SqlConnection conn = _conexao.getConexao())
            {
                string query = "Select * from tbMatricula " +
                                "Where IdCurso = @IdCurso And IdAluno = @IdAluno";
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@IdCurso", IdCurso);
                command.Parameters.AddWithValue("@IdAluno", IdAluno);

                // Abrindo a conexão com o banco de dados
                conn.Open();

                // Usando um objeto DataReader para ler os dados do banco
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    // Enquanto conseguir ler algum dado do banco...
                    while (reader.Read())
                    {
                        matricula = new MatriculaViewModel();

                        // Obter os dados e criar um objeto Matricula
                        MatriculaViewModel Matricula = new MatriculaViewModel();
                        matricula.IdCurso = Int32.Parse(reader["IdCurso"].ToString());
                        matricula.IdAluno = Int32.Parse(reader["IdCurso"].ToString());
                        matricula.DataMatricula = DateOnly.Parse(
                            reader["DataMatricula"].ToString().Substring(0, 10)
                        );
                    }
                }

                // Fechando a conexão com o banco
                conn.Close();
            }

            return matricula;
        }

        public async Task<MatriculaViewModel> obterMatricula(MatriculaInputModel Matricula)
        {
            MatriculaViewModel matriculaAux = null;

            using (SqlConnection conn = _conexao.getConexao())
            {
                // Criando a instrução SQL e o objeto command para executá-la
                string query = "Select Top 1 * from tbMatricula " +
                               "Where IdCurso = @IdCurso And IdAluno = @IdAluno " +
                               "Order By IdCurso, IdAluno Desc";
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@IdCurso", Matricula.IdCurso);
                command.Parameters.AddWithValue("@IdAluno", Matricula.IdAluno);


                // Abrindo a conexão com o banco de dados
                conn.Open();

                // Usando um objeto DataReader para ler os dados do banco
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    // Enquanto conseguir ler algum dado do banco...
                    while (reader.Read())
                    {
                        matriculaAux = new MatriculaViewModel();

                        // Obter os dados e criar um objeto Matricula
                        matriculaAux.IdCurso = Int32.Parse(reader["IdCurso"].ToString());
                        matriculaAux.IdAluno = Int32.Parse(reader["IdAluno"].ToString());
                    }
                }

                // Fechando a conexão com o banco
                conn.Close();
            }

            return matriculaAux;
        }

        public async Task<MatriculaViewModel> insert(MatriculaInputModel matricula)
        {
            MatriculaViewModel matriculaAux = null;

            using (SqlConnection conn = _conexao.getConexao())
            {
                // Criando a instrução SQL e o objeto command para executá-la
                string query = "Insert Into tbMatricula (IdCurso, IdAluno, DataMatricula) " +
                               "Values (@IdCurso, @IdAluno, @DataMatricula)";
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@IdCurso", matricula.IdCurso);
                command.Parameters.AddWithValue("@IdAluno", matricula.IdAluno);
                command.Parameters.AddWithValue("@DataMatricula", DateTime.Today);

                // Abrindo a conexão com o banco de dados
                conn.Open();

                // Executando o comando
                await command.ExecuteNonQueryAsync();

                // Fechando a conexão com o banco
                conn.Close();
            }

            matriculaAux = await obterMatricula(matricula);
            return matriculaAux;
        }

        public async Task<MatriculaViewModel> delete(int IdCurso, int IdAluno)
        {

            MatriculaViewModel matriculaAux = await obterPorId(IdCurso, IdAluno);

            using (SqlConnection conn = _conexao.getConexao())
            {
                // Criando a instrução SQL e o objeto command para executá-la
                string query = "Delete From tbMatricula " +
                               "Where IdCurso= @IdCurso and IdAluno= @IdAluno";
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@IdCurso", IdCurso);
                command.Parameters.AddWithValue("@IdAluno", IdAluno);

                // Abrindo a conexão com o banco de dados
                conn.Open();

                // Executando o comando
                await command.ExecuteNonQueryAsync();

                // Fechando a conexão com o banco
                conn.Close();
            }

            return matriculaAux;
        }
    }
}
