﻿using API_DB.Models.Data;
using API_DB.Models.InputModels;
using API_DB.Models.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API_DB.Controllers
{
    [Route("api/v1/[controller]")]
    [ApiController]
    public class MatriculaController : ControllerBase
    {
        private readonly ILogger<MatriculaController> _logger;
        private readonly MatriculaDB _MatriculaDB;

        public MatriculaController(ILogger<MatriculaController> logger, MatriculaDB MatriculaDB)
        {
            _logger = logger;
            _MatriculaDB = MatriculaDB;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<MatriculaViewModel>>> getCursos()
        {
            try
            {
                var dados = await _MatriculaDB.listar();
                if (dados != null)
                    return Ok(dados);
                else
                    return NoContent();
            }
            catch (Exception)
            {
                return BadRequest("Não foi possível obter a lista de matrículas!");
            }
        }

        [HttpPost]
        public async Task<ActionResult<MatriculaViewModel>> InsertMatricula(
            [FromBody] MatriculaInputModel matricula
        )
        {
            try
            {
                var dados = await _MatriculaDB.insert(matricula);
                return Ok(dados);
            }
            catch (Exception e)
            {
                return UnprocessableEntity("Não foi possível inserir a matrícula!" + e);
            }
        }

        [HttpDelete("{IdCurso}/{IdAluno}")]
        public async Task<ActionResult<MatriculaViewModel>> Delete([FromRoute] int IdCurso, int IdAluno)
        {
            try
            {
                var dados = await _MatriculaDB.delete( IdCurso, IdAluno);
                return Ok(dados);
            }
            catch (Exception)
            {
                return UnprocessableEntity("Não foi possível excluir a matrícula!");
            }
        }

    }
}
