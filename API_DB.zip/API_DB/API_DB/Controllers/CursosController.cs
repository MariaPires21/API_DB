﻿using API_DB.Models.Data;
using API_DB.Models.InputModels;
using API_DB.Models.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API_DB.Controllers
{
    [Route("api/v1/[controller]")]
    [ApiController]
    public class CursosController : ControllerBase
    {
        private readonly ILogger<CursosController> _logger;
        private readonly CursosDB _cursoDB;

        public CursosController(ILogger<CursosController> logger, CursosDB cursoDB)
        {
            _logger = logger;
            _cursoDB = cursoDB;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<CursoViewModel>>> getCursos()
        {
            try
            {
                var dados = await _cursoDB.listar();
                if (dados != null)
                    return Ok(dados);
                else
                    return NoContent();
            }
            catch (Exception)
            {
                return BadRequest("Não foi possível obter a lista de cursos!");
            }
        }

        [HttpGet("{Id}")]
        public async Task<ActionResult<CursoViewModel>> getCursoById([FromRoute] int Id)
        {
            try
            {
                var dados = await _cursoDB.obterPorId(Id);
                if (dados != null)
                    return Ok(dados);
                else
                    return NoContent();
            }
            catch (Exception)
            {
                return BadRequest("Não foi possível encontrar o curso!");
            }
        }

        [HttpPost]
        public async Task<ActionResult<CursoViewModel>> InsertCurso(
            [FromBody] CursosInputModel curso
        )
        {
            try
            {
                var dados = await _cursoDB.insert(curso);
                return Ok(dados);
            }
            catch (Exception)
            {
                return UnprocessableEntity("Não foi possível inserir o curso!");
            }
        }

        [HttpPut("{Id}")]
        public async Task<ActionResult<CursoViewModel>> UpdateCurso(
            [FromRoute] int Id, [FromBody] CursosInputModel curso
        )
        {
            try
            {
                var dados = await _cursoDB.update(Id, curso);
                return Ok(dados);
            }
            catch (Exception)
            {
                return UnprocessableEntity("Não foi possível atualizar o curso!");
            }
        }

        [HttpDelete("{Id}")]
        public async Task<ActionResult<CursoViewModel>> Delete([FromRoute] int Id)
        {
            try
            {
                var dados = await _cursoDB.delete(Id);
                return Ok(dados);
            }
            catch (Exception)
            {
                return UnprocessableEntity("Não foi possível excluir o curso!");
            }
        }

    }
}
