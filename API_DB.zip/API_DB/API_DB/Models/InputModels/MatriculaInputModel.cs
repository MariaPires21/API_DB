﻿namespace API_DB.Models.InputModels
{
    public class MatriculaInputModel
    {
        public int IdCurso { get; set; }
        public int IdAluno { get; set; }
    }
}
