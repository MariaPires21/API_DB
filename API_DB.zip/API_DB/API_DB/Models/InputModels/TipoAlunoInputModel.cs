﻿namespace API_DB.Models.InputModels
{
    public class TipoAlunoInputModel
    {
        public string Tipo { get; set; }
    }
}
