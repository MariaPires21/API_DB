﻿namespace API_DB.Models.ViewModels
{
    public class MatriculaViewModel
    {
        public int IdCurso { get; set; }
        public int IdAluno { get; set; }
        public DateOnly DataMatricula { get; set; }    
    }

}
