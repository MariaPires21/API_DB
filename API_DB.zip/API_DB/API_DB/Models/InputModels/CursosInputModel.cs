﻿namespace API_DB.Models.InputModels
{
    public class CursosInputModel
    {
        public string Curso { get; set; }
        public string Sigla { get; set; }
        public int CargaHoraria { get; set; }
    }
}
