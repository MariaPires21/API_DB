﻿namespace API_DB.Models.ViewModels
{
    public class TipoAlunoViewModel
    {
        public int IdTipo { get; set; }
        public string Tipo{ get; set; }
    }
}
