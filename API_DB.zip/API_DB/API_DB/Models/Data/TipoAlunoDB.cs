﻿using API_DB.Models.InputModels;
using API_DB.Models.ViewModels;
using System.Data.SqlClient;

namespace API_DB.Models.Data
{
    public class TipoAlunoDB
    {
        private readonly IConexao _conexao;

        public TipoAlunoDB(IConexao conexao)
        {
            _conexao = conexao;
        }

        /* Implementar métodos para banco de dados */

        public async Task<List<TipoAlunoViewModel>> listar()
        {
            List<TipoAlunoViewModel> tpalunos = new List<TipoAlunoViewModel>();

            using (SqlConnection conn = _conexao.getConexao())
            {
                string query = "Select * from tbTipoAluno";
                SqlCommand command = new SqlCommand(query, conn);

                // Abrindo a conexão com o banco de dados
                conn.Open();

                // Usando um objeto DataReader para ler os dados do banco
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    // Enquanto conseguir ler algum dado do banco...
                    while (reader.Read())
                    {
                        // Obter os dados e criar um objeto Aluno
                        TipoAlunoViewModel tpaluno = new TipoAlunoViewModel();
                        tpaluno.IdTipo = Int32.Parse(reader["IdTipo"].ToString());
                        tpaluno.Tipo = reader["Tipo"].ToString();

                        // Adicionando o novo Aluno na lista
                         tpalunos.Add(tpaluno);
                    }
                }

                // Fechando a conexão com o banco
                conn.Close();
            }

            return tpalunos;
        }

        public async Task<TipoAlunoViewModel> obterPorId(int Id)
        {
            TipoAlunoViewModel tpaluno = null;

            using (SqlConnection conn = _conexao.getConexao())
            {
                string query = "Select * from tbTipoAluno " +
                    "Where IdTipo = @IdTipo";
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@IdTipo", Id);


                // Abrindo a conexão com o banco de dados
                conn.Open();

                // Usando um objeto DataReader para ler os dados do banco
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    // Enquanto conseguir ler algum dado do banco...
                    while (reader.Read())
                    {
                        tpaluno = new TipoAlunoViewModel();

                        // Obter os dados e criar um objeto Aluno
                        tpaluno.IdTipo = Int32.Parse(reader["IdTipo"].ToString());
                        tpaluno.Tipo = reader["Tipo"].ToString();
                    }
                }

                // Fechando a conexão com o banco
                conn.Close();
            }

            return tpaluno;
        }

        public async Task<TipoAlunoViewModel> obterTipo(TipoAlunoInputModel tpaluno)
        {
            TipoAlunoViewModel tpalunoAux = null;

            using (SqlConnection conn = _conexao.getConexao())
            {
                // Criando a instrução SQL e o objeto command para executá-la
                string query = "Select Top 1 * from tbTipoAluno " +
                               "Where Tipo = @Tipo " +
                               "Order By IdTipo Desc";
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@Tipo", tpaluno.Tipo);

                // Abrindo a conexão com o banco de dados
                conn.Open();

                // Usando um objeto DataReader para ler os dados do banco
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    // Enquanto conseguir ler algum dado do banco...
                    while (reader.Read())
                    {
                        tpalunoAux = new TipoAlunoViewModel();

                        // Obter os dados e criar um objeto Aluno
                        tpalunoAux.IdTipo = Int32.Parse(reader["IdTipo"].ToString());
                        tpalunoAux.Tipo = reader["Tipo"].ToString();
                    }
                }

                // Fechando a conexão com o banco
                conn.Close();
            }

            return tpalunoAux;
        }

        public async Task<TipoAlunoViewModel> insert(TipoAlunoInputModel tpaluno)
        {
            TipoAlunoViewModel tpalunoAux = null;

            using (SqlConnection conn = _conexao.getConexao())
            {
                // Criando a instrução SQL e o objeto command para executá-la
                string query = "Insert Into tbTipoAluno (IdTipo, Tipo) " +
                               "Values ((Select Max(IdTipo)+1 From tbTipoAluno), @Tipo )";
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@Tipo", tpaluno.Tipo);

                // Abrindo a conexão com o banco de dados
                conn.Open();

                // Executando o comando
                await command.ExecuteNonQueryAsync();

                // Fechando a conexão com o banco
                conn.Close();
            }

            tpalunoAux = await obterTipo(tpaluno);
            return tpalunoAux;
        }

        public async Task<TipoAlunoViewModel> update(int Id, TipoAlunoInputModel tpaluno)
        {
            TipoAlunoViewModel tpalunoAux = null;

            using (SqlConnection conn = _conexao.getConexao())
            {
                // Criando a instrução SQL e o objeto command para executá-la
                string query = "Update tbTipoAluno " +
                               "Set Tipo=@Tipo " +
                               "Where IdTipo=@IdTipo";
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@IdTipo", Id);
                command.Parameters.AddWithValue("@Tipo", tpaluno.Tipo);

                // Abrindo a conexão com o banco de dados
                conn.Open();

                // Executando o comando
                await command.ExecuteNonQueryAsync();

                // Fechando a conexão com o banco
                conn.Close();
            }
            

            tpalunoAux = await obterTipo(tpaluno);
            return tpalunoAux;
        }

        public async Task<TipoAlunoViewModel> delete(int Id)
        {

            TipoAlunoViewModel tpalunoAux = await obterPorId(Id);

            using (SqlConnection conn = _conexao.getConexao())
            {
                // Criando a instrução SQL e o objeto command para executá-la
                string query = "Delete From tbTipoAluno " +
                               "Where IdTipo=@Id";
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@Id", Id);

                // Abrindo a conexão com o banco de dados
                conn.Open();

                // Executando o comando
                await command.ExecuteNonQueryAsync();

                // Fechando a conexão com o banco
                conn.Close();
            }

            return tpalunoAux;
        }

    }
}
